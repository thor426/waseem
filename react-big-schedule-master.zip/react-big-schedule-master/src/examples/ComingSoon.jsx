import React from 'react';
import { Result } from 'antd';

function ComingSoon() {
  return <Result status="404" title="Sorry, the example is on the way!" style={{ marginTop: '25vh' }} />;
}

export default ComingSoon;
